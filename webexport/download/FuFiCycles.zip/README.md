#FuFiCycles (a FuFi production)


###Keys
#####Ingame
LEFT  - Player 1 turn left
RIGHT - Player 1 turn right
A     - Player 2 turn left
D     - Player 2 turn right

#####Menu

C     - Continue
N     - New Match
ESC   - Close Game (only offline)

### online
To open the game only visit fuficycles.florianfirmenich.de